#-*- coding: UTF-8 -*-
__author__ = 'minhuaxu'

import os

if __name__ == '__main__':
    os.system("adb pull /data/com.tencent.tmgp.speedmobile/files/NssMemoryLog/Memory---.txt upload.dir")
